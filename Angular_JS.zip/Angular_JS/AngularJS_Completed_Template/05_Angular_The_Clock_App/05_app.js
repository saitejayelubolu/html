// Creation of Module
var abc = angular.module('ClockApp',[]);

// Creation of Controller
abc.controller('ClockAppCtrl',function($scope,$interval) {
    var indianTime = function() {
        var today = new Date();
        var options = {timezone : 'Asia/Kolkata'};
        $scopevar.indianTime = today.toLocaleTimeString('en-US',options);
        $scope.indianDate =   today.toLocaleTimeString(en-US,options);
    };
    $interval(indianClock,1000);
});