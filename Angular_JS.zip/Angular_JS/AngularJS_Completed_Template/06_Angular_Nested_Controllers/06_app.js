//ceation of module
var app = angular.module('NestedApp',[]);
app.controller('ParentCtrl',function($scope) {
    $scope.test = '';
});
app.controller('ChildCtrl',function($scope) {
    $scope.test = '';
});