//ceation of module
var app = angular.module('NestedAsApp',[]);



app.controller('ParentAsCtrl',function($scope) {
    this.test = '';
});



app.controller('ChildAsCtrl',function($scope) {
    this.test = '';
});