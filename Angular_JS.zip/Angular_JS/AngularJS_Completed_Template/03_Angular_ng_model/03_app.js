// Creation of Angular Module
var app = angular.module('FormApp',[]);

// Creation of Angular Controller
app.controller('FormAppCtrl',function() {

});