//ceation of module
 var app = angular.module('CalcApp',[]);



app.controller('CalcAppCtrl',function($scope) {
     this.operator = '+';
    this.changeoperator = function(opr) {
      this.operator = opr;
    };
 });



